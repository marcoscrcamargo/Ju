#ifndef _HEAPSORT_H_
#define _HEAPSORT_H_

void correctUp(NO** vector, int index);
void heapsort_(NO **, int);

#endif
